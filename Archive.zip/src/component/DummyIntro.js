import React from 'react';

class DummyIntro extends React.Component {

    render() {
        return (
            <div>
                Loading.....
            </div>
        );
    }
}

export default DummyIntro;